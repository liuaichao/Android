package cn.bmob.sdkdemo;

import cn.bmob.v3.BmobInstallation;


public class MyInstallation extends BmobInstallation{
    private String uid;

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

}
