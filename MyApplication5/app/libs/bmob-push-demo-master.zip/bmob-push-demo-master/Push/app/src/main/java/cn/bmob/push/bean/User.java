package cn.bmob.push.bean;

import cn.bmob.v3.BmobUser;

/**
 * Created on 17/8/24 13:03
 */

public class User extends BmobUser {

}
